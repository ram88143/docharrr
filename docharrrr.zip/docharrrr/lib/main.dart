import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'pages/home_page.dart';
import 'pages/payment_confirmation_page.dart';  // Correct import for PaymentConfirmationPage
import 'pages/donation_history_page.dart';
import 'pages/thank_you_page.dart';  // Correct import for ThankYouPage
import 'pages/charity_list_page.dart';
import 'pages/donation_page.dart';
import 'pages/sign_up_page.dart';  // Import for SignUpPage

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Donation App',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      initialRoute: '/', // Start at Login Page
      routes: {
        '/': (context) => LoginPage(),
        '/home': (context) => HomePage(),
        '/charityList': (context) => CharityListPage(),
        '/donation': (context) => DonationPage(),
        '/paymentConfirmation': (context) => PaymentConfirmationPage(), // Correct reference for PaymentConfirmationPage widget
        '/thankYou': (context) => ThankYouPage(), // Correct reference for ThankYouPage widget
        '/donationHistory': (context) => DonationHistoryPage(),
        '/signUp': (context) => SignUpPage(), // Add the route for SignUpPage
      },
    );
  }
}
