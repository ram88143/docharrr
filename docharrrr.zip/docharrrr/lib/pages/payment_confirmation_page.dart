import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaymentConfirmationPage extends StatefulWidget {
  @override
  _PaymentConfirmationPageState createState() =>
      _PaymentConfirmationPageState();
}

class _PaymentConfirmationPageState extends State<PaymentConfirmationPage> {
  final _cardNumberController = TextEditingController();
  final _expiryDateController = TextEditingController();
  final _cvvController = TextEditingController();
  final _cardHolderNameController = TextEditingController();

  final _formKey = GlobalKey<FormState>(); // Form key for validation
  final FocusNode _expiryFocusNode = FocusNode(); // Focus node for expiry date
  final FocusNode _cvvFocusNode = FocusNode(); // Focus node for CVV

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> args =
    ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final String charityName = args['charity'];
    final double amount = args['amount'];
    final String donorName = args['name'];
    final String donorEmail = args['email'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Payment Confirmation'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey, // Attach form key for validation
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Confirmation for $charityName',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text('Donor Name: $donorName'),
              Text('Email: $donorEmail'),
              Text('Donation Amount: ₹$amount'),
              SizedBox(height: 20),
              // Cardholder Name input field
              TextFormField(
                controller: _cardHolderNameController,
                decoration: InputDecoration(
                  labelText: 'Cardholder Name',
                  labelStyle: TextStyle(color: Colors.deepPurple),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Cardholder name is required';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              // Card Number input field
              TextFormField(
                controller: _cardNumberController,
                decoration: InputDecoration(
                  labelText: 'Card Number',
                  labelStyle: TextStyle(color: Colors.deepPurple),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                keyboardType: TextInputType.number,
                maxLength: 12, // 12 digits
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly, // Allow only digits
                  LengthLimitingTextInputFormatter(12), // Limit total length to 12 digits
                ],
                validator: (value) {
                  if (value == null || value.length != 12) {
                    return 'Enter a valid 12-digit card number';
                  }
                  return null;
                },
                onFieldSubmitted: (_) {
                  FocusScope.of(context).requestFocus(_expiryFocusNode);
                },
              ),
              SizedBox(height: 20),
              // Expiry Date input field
              TextFormField(
                controller: _expiryDateController,
                focusNode: _expiryFocusNode,
                decoration: InputDecoration(
                  labelText: 'Expiry Date (MM/YY)',
                  labelStyle: TextStyle(color: Colors.deepPurple),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                keyboardType: TextInputType.number,
                maxLength: 5, // MM/YY format
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(4),
                  TextInputFormatter.withFunction((oldValue, newValue) {
                    String newText = newValue.text.replaceAll(RegExp(r'\D'), ''); // Remove non-digit characters
                    if (newText.length > 4) return oldValue;

                    if (newText.length >= 3) {
                      newText = '${newText.substring(0, 2)}/${newText.substring(2)}';
                    }
                    return TextEditingValue(
                      text: newText,
                      selection: TextSelection.collapsed(offset: newText.length),
                    );
                  }),
                ],
                validator: (value) {
                  if (value == null || !RegExp(r'^(0[1-9]|1[0-2])\/\d{2}$').hasMatch(value)) {
                    return 'Enter a valid expiry date (MM/YY)';
                  }
                  return null;
                },
                onFieldSubmitted: (_) {
                  FocusScope.of(context).requestFocus(_cvvFocusNode);
                },
              ),
              SizedBox(height: 20),
              // CVV input field
              TextFormField(
                controller: _cvvController,
                focusNode: _cvvFocusNode,
                decoration: InputDecoration(
                  labelText: 'CVV',
                  labelStyle: TextStyle(color: Colors.deepPurple),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                keyboardType: TextInputType.number,
                maxLength: 3,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                validator: (value) {
                  if (value == null || value.length != 3) {
                    return 'Enter a valid 3-digit CVV';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              // Confirm Payment Button
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    SharedPreferences prefs = await SharedPreferences.getInstance();
                    List<String> donationHistory =
                        prefs.getStringList('donationHistory') ?? [];

                    String donationDetail =
                        'Charity: $charityName, Amount: ₹$amount, Donor: $donorName';
                    donationHistory.add(donationDetail);

                    await prefs.setStringList('donationHistory', donationHistory);

                    Navigator.pushNamed(
                      context,
                      '/thankYou',
                      arguments: {
                        'charity': charityName,
                        'amount': amount,
                        'name': donorName,
                        'email': donorEmail,
                      },
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Please fill in all payment details')),
                    );
                  }
                },
                child: Padding(
                  padding:
                  const EdgeInsets.symmetric(vertical: 15.0, horizontal: 40.0),
                  child: Text(
                    'Confirm Payment',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  elevation: 5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
