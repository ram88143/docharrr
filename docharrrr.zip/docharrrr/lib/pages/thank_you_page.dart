// thank_you_page.dart
import 'package:flutter/material.dart';

class ThankYouPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Retrieve the donation details passed from PaymentConfirmationPage
    final Map<String, dynamic> args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final String charityName = args['charity'];
    final double amount = args['amount'];
    final String donorName = args['name'];
    final String donorEmail = args['email'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Thank You!'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView( // To make sure the page is scrollable
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                'Thank you for your donation!',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 30),
            Text(
              'Donation Details:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Charity: $charityName'),
            Text('Amount: ₹$amount'),
            Text('Donor: $donorName'),
            Text('Email: $donorEmail'),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Navigate back to HomePage or any other page after donation
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 40.0),
                child: Text(
                  'Back to Home',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600, // Added font weight for button text
                    color: Colors.white, // Text color white
                  ),
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple, // Button color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                elevation: 5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
