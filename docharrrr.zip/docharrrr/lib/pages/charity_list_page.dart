import 'package:flutter/material.dart';

class CharityListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // List of top Indian charities with names and descriptions
    final List<Map<String, String>> charities = [
      {"name": "Goonj", "description": "Bringing urban surplus to rural areas."},
      {"name": "Akshaya Patra Foundation", "description": "Providing mid-day meals to children."},
      {"name": "Smile Foundation", "description": "Education and healthcare for underprivileged children."},
      {"name": "HelpAge India", "description": "Supporting the elderly in India."},
      {"name": "Pratham Education Foundation", "description": "Improving education for underprivileged children."},
      {"name": "CRY (Child Rights and You)", "description": "Focusing on child rights and education."},
      {"name": "Teach for India", "description": "Improving education in underserved communities."},
      {"name": "Sightsavers India", "description": "Preventing blindness and promoting eye health."},
      {"name": "Nanhi Kali", "description": "Education support for underprivileged girls."},
      {"name": "GiveIndia", "description": "Enabling donors to support a variety of causes."},
    ];

    return Scaffold(
      appBar: AppBar(title: Text('Top Indian Charities')),
      body: ListView.builder(
        itemCount: charities.length,
        itemBuilder: (context, index) {
          final charity = charities[index];
          return ListTile(
            title: Text(charity["name"]!),
            subtitle: Text(charity["description"]!),
            onTap: () {
              // Pass the entire charity data (Map) to the donation page
              Navigator.pushNamed(
                context,
                '/donation',
                arguments: charity, // Pass the entire charity Map
              );
            },
          );
        },
      ),
    );
  }
}
