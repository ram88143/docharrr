import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DonationHistoryPage extends StatefulWidget {
  @override
  _DonationHistoryPageState createState() => _DonationHistoryPageState();
}

class _DonationHistoryPageState extends State<DonationHistoryPage> {
  List<String> donationHistory = [];
  final ScrollController _scrollController = ScrollController(); // Controller for the scrollable view

  @override
  void initState() {
    super.initState();
    _loadDonationHistory();
  }

  @override
  void dispose() {
    _scrollController.dispose(); // Dispose the controller to free up resources
    super.dispose();
  }

  // Load donation history from SharedPreferences
  _loadDonationHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      donationHistory = prefs.getStringList('donationHistory') ?? [];
    });
  }

  // Clear donation history from SharedPreferences
  _clearDonationHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('donationHistory');
    setState(() {
      donationHistory = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Donation History',
          style: TextStyle(color: Colors.white), // Set text color to white
        ),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
            icon: Icon(Icons.delete), // Trash icon for clearing history
            onPressed: () {
              _clearDonationHistory(); // Call the method to clear donation history
            },
            tooltip: 'Clear Donation History', // Tooltip for accessibility
          ),
        ],
      ),
      body: donationHistory.isEmpty
          ? Center(child: Text('No donation history available.')) // If no history, show a message
          : Scrollbar(
        thumbVisibility: true, // Make the scrollbar visible during scrolling
        controller: _scrollController, // Attach the scrollbar to the controller
        child: ListView.builder(
          controller: _scrollController, // Attach the ListView to the same controller
          itemCount: donationHistory.length,
          itemBuilder: (context, index) {
            final donationDetail = donationHistory[index];
            return ListTile(
              title: Text(donationDetail), // Display each donation detail
            );
          },
        ),
      ),
    );
  }
}
