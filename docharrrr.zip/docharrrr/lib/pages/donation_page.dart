import 'package:flutter/material.dart';

class DonationPage extends StatefulWidget {
  @override
  _DonationPageState createState() => _DonationPageState();
}

class _DonationPageState extends State<DonationPage> {
  final _amountController = TextEditingController();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // Retrieve the charity data passed from the previous page (charity name and description)
    final Map<String, String> charity = ModalRoute.of(context)!.settings.arguments as Map<String, String>;
    final String charityName = charity['name']!; // Get the charity name from the Map

    return Scaffold(
      appBar: AppBar(
        title: Text('Donate to $charityName'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Name input field
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Your Name',
                labelStyle: TextStyle(color: Colors.deepPurple),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
            ),
            SizedBox(height: 20),

            // Email input field
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Your Email',
                labelStyle: TextStyle(color: Colors.deepPurple),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
            ),
            SizedBox(height: 20),

            // Amount input field
            TextField(
              controller: _amountController,
              decoration: InputDecoration(
                labelText: 'Donation Amount',
                labelStyle: TextStyle(color: Colors.deepPurple),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),

            // Proceed to payment button with custom text color
            ElevatedButton(
              onPressed: () {
                final double amount = double.tryParse(_amountController.text) ?? 0;
                if (amount > 0) {
                  // Pass charity details, donation amount, name, and email to payment confirmation
                  Navigator.pushNamed(
                    context,
                    '/paymentConfirmation',
                    arguments: {
                      'charity': charityName,
                      'amount': amount,
                      'name': _nameController.text,
                      'email': _emailController.text,
                    },
                  );
                } else {
                  // Show error if donation amount is invalid
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Please enter a valid donation amount')),
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 40.0),
                child: Text(
                  'Proceed to Payment',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Set the text color to white
                  ),
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                elevation: 5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
