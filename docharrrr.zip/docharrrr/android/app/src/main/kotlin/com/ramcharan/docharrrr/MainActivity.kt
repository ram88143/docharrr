package com.ramcharan.docharrrr

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
